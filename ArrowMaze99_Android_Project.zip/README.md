# Arrow Maze 99 — Android Project

This is an Android Studio project wrapping the HTML game in a local WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android phone/emulator.
4. For Google Play, choose Build > Generate Signed App Bundle / APK.
5. Select Android App Bundle (AAB), create/use a signing key, and build the release AAB.

## Package
com.ubaidullah.arrowmaze99

## Current target
compileSdk 36 / targetSdk 36

## Game
The HTML game is in:
app/src/main/assets/index.html

You can edit that file and rebuild the Android app.
