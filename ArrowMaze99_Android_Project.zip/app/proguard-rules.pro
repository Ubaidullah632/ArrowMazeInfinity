# Arrow Maze 99 - no custom rules yet
